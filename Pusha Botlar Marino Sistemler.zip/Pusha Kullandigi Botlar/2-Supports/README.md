# Ozi-Destek-Bots

- Testleri yapılmıştır. Hiçbir hatası bulunmamaktadır starlarınızı bekliyorum yeni github hesabım.
- Sizlerle geliştirmiş olduğum botlardan biriyle tanıştırmak istiyorum.. 
- Yetkili Alım, İstek/Öneri, Sikayet, Support sistemleri.

![image](https://user-images.githubusercontent.com/92666466/146657470-84347794-39a9-4fe2-9e5f-5a2dd5871ca6.png)
![image](https://user-images.githubusercontent.com/92666466/146657476-e297a208-8115-41c3-aa3c-e5194491fbb9.png)
![image](https://user-images.githubusercontent.com/92666466/146657480-d69ed19d-f6b5-4862-bb76-8d078675487b.png)
![image](https://user-images.githubusercontent.com/92666466/146657483-2d628a64-4aa6-4d96-a114-e0d4fe81a026.png)
![image](https://user-images.githubusercontent.com/92666466/146657487-05f5373a-fbaf-43d4-a9e0-38d05224b028.png)
![image](https://user-images.githubusercontent.com/92666466/146657491-aac492d3-cd3c-42b6-8458-af9c794fa03e.png)
![image](https://user-images.githubusercontent.com/92666466/146657492-2477dedd-0070-402e-aaab-18b2546eb747.png)
![image](https://user-images.githubusercontent.com/92666466/146657496-c6b2e950-5701-4f19-a376-d785885f2a03.png)
![image](https://user-images.githubusercontent.com/92666466/146657506-6b763978-4bff-4165-87fb-e4477d88c039.png)
![image](https://user-images.githubusercontent.com/92666466/146657510-d8ce7b09-7662-4238-a363-613b9b3be5b0.png)
![image](https://user-images.githubusercontent.com/92666466/146657511-70db455b-1cbd-4002-9510-4d59616a4441.png)
![image](https://user-images.githubusercontent.com/92666466/146657513-99bdc9b5-694b-47d7-87c6-4f03064ae634.png)
![image](https://user-images.githubusercontent.com/92666466/146657518-b9097ad8-f4e1-460d-b21a-468134b49388.png)
![image](https://user-images.githubusercontent.com/92666466/146657520-6b907335-1d47-43f3-815b-892e208f2443.png)
![image](https://user-images.githubusercontent.com/92666466/146657529-8e65d752-190c-42d3-a560-91b9e99aa325.png)
![image](https://user-images.githubusercontent.com/92666466/146657533-890b6786-d7ee-4b89-8850-08c06284b663.png)
![image](https://user-images.githubusercontent.com/92666466/146657536-95bc80e7-809e-4cb2-9a40-3305bba3de88.png)
![image](https://user-images.githubusercontent.com/92666466/146657538-29c11ca9-44c6-4d68-874c-b6944a8c12bf.png)
