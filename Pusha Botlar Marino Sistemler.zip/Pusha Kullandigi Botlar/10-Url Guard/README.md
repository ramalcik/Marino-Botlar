# Url-Spammer
Selam Herkese Bu Bot İle Zamanında vlr,lastarnmy,poseidon,valencia Gibi Birçok Önemli Urlyi Aldım (Örnek Olarak Verdim Bunları) Birazdaha Geliştirip Sizlere Sundum.

``Yapmanız Gerekenler;``

``cyber.json`` Dosyasındaki Gerekli Yerleri Girdikten Sonra Bot Hazır Olacaktır.

``spamsaniyebot1`` Bunların Hepsini Farklı Girin Minimum 2500 , Maximum 5000 Olsun Rate Limited Hatası Alabilirsiniz Kendi Kendine Düzelir.

Star Atarsanız Sevinirim.

Discord: Cyber Râte#1920
